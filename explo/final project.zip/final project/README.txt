TO INSTALL DPENDENCIES RUN IN TERMINAL:

install python version 3+

pip install -r requirements.txt



enjoy :)